""" global constants """
# for shortest path calculation
MAX_LABEL_COST = 999999
# in case where the divisor/demoninator is ZERO
SMALL_DIVISOR = 0.001
